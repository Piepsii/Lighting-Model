Course Name: Real-Time Graphics Programming for Games 1
Course Code: 5SD805 54832 HT2021
Student Name: Paul Brandstetter
Assignment Description: This is an individual assignment that consists of writing a program that simulates and renders three objects with a backdrop and Blinn lighting. The three objects have to move over time.