// main.cpp

#pragma once

#include "Spinach.h"

int main(int argc, char** argv)
{
    Application{ "Spinach",1920,1080 }.Run();
    return 0;
}