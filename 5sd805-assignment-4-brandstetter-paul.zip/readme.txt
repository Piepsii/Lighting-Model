Course Name: Real-Time Graphics Programming for Games 1
Course Code: 5SD805 54832 HT2021
Student Name: Paul Brandstetter
Assignment Description: This is an individual assignment that consists of writing a program that simulates and renders three moving objects with a floor and a wall. All objects are lit using the Blinn-Phong lighting model and cast shadows using a basic shadow mapping technique. The orthographic shadow map is rendered as a black and white overlay on the top left corner.